/*
buscar como utilizar un switch como if
Los gimnasios pueden ser clasificados por la empresa como de tipo “A” o de tipo “B”, de
acuerdo a las prestaciones observadas. Las limosinas están disponibles para cualquier
cliente, pero sujeto a disponibilidad, por lo que cuanto más limosinas tenga el hotel, más caro
será.
El precio de una habitación debe calcularse de acuerdo con la siguiente fórmula:
PrecioHabitación = $50 + ($1 x capacidad del hotel) + (valor agregado por restaurante) + (valor
agregado por gimnasio) + (valor agregado por limosinas).
Donde:
Valor agregado por el restaurante:
• $10 si la capacidad del restaurante es de menos de 30 personas.
• $30 si está entre 30 y 50 personas.
• $50 si es mayor de 50.
Valor agregado por el gimnasio:
• $50 si el tipo del gimnasio es A.
• $30 si el tipo del gimnasio es B.
Valor agregado por las limosinas:
• $15 por la cantidad de limosinas del hotel.
En contraste, los Alojamientos Extra hoteleros proveen servicios diferentes a los de los
hoteles, estando más orientados a la vida al aire libre y al turista de bajos recursos. Por cada
Alojamiento Extrahotelero se indica si es privado o no, así como la cantidad de metros
cuadrados que ocupa. Existen dos tipos de alojamientos extrahoteleros: los Camping y las
Residencias. Para los Camping se indica la capacidad máxima de carpas, la cantidad de baños
disponibles y si posee o no un restaurante dentro de las instalaciones. Para las residencias se
indica la cantidad de habitaciones, si se hacen o no descuentos a los gremios y si posee o no
campo deportivo. Realizar un programa en el que se representen todas las relaciones
descriptas.
Realizar un sistema de consulta que le permite al usuario consultar por diferentes criterios:
 */
package Paquete.Main;

import Paquete.Alojamiento.Alojamiento;
import Paquete.Enums.Gimnasio;
import Paquete.Enums.Gremio;
import Paquete.Enums.Restaurante;
import Paquete.Ordenadores.Ordenador;
import Paquete.TiposAlojamiento.Hotel;
import java.util.Collections;
import Paquete.TiposAlojamiento.TiposExtraHoteleros.Camping;
import Paquete.TiposAlojamiento.TiposExtraHoteleros.Residencias;
import Paquete.TiposAlojamiento.TiposHoteles.Hotel4;
import Paquete.TiposAlojamiento.TiposHoteles.Hotel5;
import java.util.ArrayList;


/**
 *
 * @author amat9
 */
public class Main {

    /* 
• todos los alojamientos.
• todos los hoteles de más caro a más barato.
• todos los campings con restaurante
• todos las residencias que tienen descuento.
     */
    public static void main(String[] args) {
        ArrayList<Alojamiento> alojamiento = new ArrayList();
        
        alojamiento.add(new Hotel4(Gimnasio.A, "Rest Dead", Restaurante.ENTRE30Y50, 10, 2, 6, "Los Santos", " Av. Maimara", "JUJUY", "Mariano"));
        alojamiento.add(new Hotel4(Gimnasio.B, "Mariachis ", Restaurante.MENOS30, 90, 1, 9, "Ahhhhhh", " Av. San maritn", "SALTA", "Lorenzo"));
        alojamiento.add(new Hotel4(Gimnasio.A, "LA SOMBRA", Restaurante.MAYOR50, 20, 2, 12, "Nos vemos", " calle. como", "SANTA CRUZ", "Jorge"));
        alojamiento.add(new Hotel4(Gimnasio.B, "Jordas", Restaurante.MAYOR50, 15, 3, 2, "Casi 5 estrellas", " Av. son", "POR", "Hola"));
        alojamiento.add(new Hotel4(Gimnasio.B, "Uhh??", Restaurante.ENTRE30Y50, 21, 3, 4, "vvvvvvvv", " Av. masti", "TUCUMAN", "Hueaico"));
        alojamiento.add(new Hotel4(Gimnasio.A, "t0d@ m41", Restaurante.MENOS30, 14, 5, 5, "asdasd", " Av. coco", "BS", "pons"));
        alojamiento.add(new Hotel5(12, 6, 35, Gimnasio.A, "Basta", Restaurante.MAYOR50, 100, 4, 100, "Muy caro", "Av. Ojo", "Bolsillos", "DON"));
        alojamiento.add(new Hotel5(5, 2, 10, Gimnasio.B, "Obesos", Restaurante.MAYOR50, 50, 3, 50, "LLENOS ", "calle moderada", "Mandatela", "CARLOS"));
        alojamiento.add(new Hotel5(1, 1, 2, Gimnasio.B, "Flacos", Restaurante.MAYOR50, 20, 2, 10, "VACIOS", "Av los poobres", "Bajon", "Soy"));
        alojamiento.add(new Hotel5(60, 50, 100, Gimnasio.A, "Ataque al corazon", Restaurante.MAYOR50, 500, 6, 700, "No lo puedes costear", "Av. tenes plata", "Corrupcion", "Bolsillos llenos"));
        alojamiento.add(new Camping(3, 2, Restaurante.NOHAY, true, 10.2, "Alexy's", "Ab. nkoasdknljasf", "bolivia", "IN"));
        alojamiento.add(new Camping(2, 3, Restaurante.MENOS30, false, 20.12, "ma'a", "Calle Lorenzo", "honduras", "OUT"));
        alojamiento.add(new Camping(10, 2, Restaurante.ENTRE30Y50, false, 20.2, "fas'n'fr", "Almuerzo", "brazil", "SIDE"));
        alojamiento.add(new Camping(22, 0, Restaurante.MAYOR50, true,50.9, "spoider man", "Cena", "argentina", "UP"));
        alojamiento.add(new Residencias(2, Gremio.AQUA, Boolean.FALSE, Boolean.TRUE, 2d, "Los ANGE", " Av. Mai", "WHO", "ASLO"));
        alojamiento.add(new Residencias(3, Gremio.LUZ, Boolean.FALSE, Boolean.TRUE, 6d, "NO", " Av. San m", "JUMP", "FARCO"));
        alojamiento.add(new Residencias(4, Gremio.NO, Boolean.FALSE, Boolean.TRUE, 9d, "Casi", " Avenia", "FOR", "HOU"));
        alojamiento.add(new Residencias(12, Gremio.CEDEM, Boolean.FALSE, Boolean.TRUE,123d, "NEOM", " Av. mas", "TMAN", "LOPO"));
        
        for (Alojamiento alojamiento1 : alojamiento) {
            alojamiento1.precio();
        }
        
        Collections.sort(alojamiento, Ordenador.OrdenPrecioCaroBarato);
        
        for (Alojamiento hotel : alojamiento) {
            if (hotel instanceof Hotel) {
                System.out.println(hotel);
            }
        }
        System.out.println("////////");
        for (Alojamiento alojamiento1 : alojamiento) {
            
            if (alojamiento1 instanceof Camping ) {
                
                if (((Camping) alojamiento1).getRestaurante()!=Restaurante.NOHAY) {
                    System.out.println(alojamiento1.toString());
                }
            }
        }
        
         System.out.println("////////");
        for (Alojamiento alojamiento2 : alojamiento) {
            
            if (alojamiento2 instanceof Residencias ) {
                
                if (((Residencias) alojamiento2).getGremio()!=Gremio.NO) {
                    System.out.println(alojamiento2.toString());
                }
            }
        }
        
    }

}
