/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package Paquete.Enums;

/**
 *
 * @author amat9
 */
public enum Gimnasio {
    A("A",50d),B("B",30d);
    
    private String tipo;
    private Double precio;

    private Gimnasio(String tipo, Double precio) {
        this.tipo = tipo;
        this.precio = precio;
    }
    public String getTipo(){
        return tipo;
    }
    public Double getPrecio(){
        return precio;
    }
    public static Gimnasio conseguirGimnasio(String gimnasio){
        for(Gimnasio gim : Gimnasio.values()){
            if (gim.getTipo().equalsIgnoreCase(gimnasio)) {
                return gim;
            }
        }
        return Gimnasio.A;
    }
}
