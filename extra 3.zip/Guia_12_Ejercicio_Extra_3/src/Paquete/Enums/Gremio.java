/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package Paquete.Enums;

/**
 *
 * @author amat9
 */
public enum Gremio {
    CEDEM("cedem",0.1),CTA("cta",0.30),AQUA("aqua",0.7),LUZ("luz",0.15),NO("",1D);
    private final String gremio;
    private final Double descuento;
    
    private Gremio(String gremio,Double descuento){
        this.gremio = gremio;
        this.descuento = descuento;
    }
    public String getGremio(){
        return gremio;
    }
    public Double getDescuento(){
        return descuento;
    }
    public static Gremio conseguirDescuento(String gremio){
        for(Gremio grem : Gremio.values()){
            if (grem.getGremio().equalsIgnoreCase(gremio)) {
                return grem;
            }
        }
        return Gremio.NO;
    }
}
