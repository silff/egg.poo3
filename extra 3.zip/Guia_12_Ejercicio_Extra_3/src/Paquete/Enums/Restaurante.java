/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package Paquete.Enums;

/*• $10 si la capacidad del restaurante es de menos de 30 personas.
• $30 si está entre 30 y 50 personas.
• $50 si es mayor de 50.
 */
public enum Restaurante {
    MENOS30(1,30,10D),ENTRE30Y50(30,50,30d),MAYOR50(51,100,50d),NOHAY(0,0,0);
    
    private int minV;
    private int maxV;
    private double precio;
    
    private Restaurante(int minV,int maxV,double precio){
        this.minV = minV;
        this.maxV = maxV;
        this.precio = precio;
    }
    public boolean isInRange(int value){
        return value >= minV && value<=maxV;
        /* codigo
         for (Peso aux : Peso.values()) {
            if (aux.isInRange(peso)) {
                return aux;
            }
        }
        return Peso.MAYOR;
        */
    }
    public double getPrecio() {
        return precio;
    }
    public static Restaurante conseguirRestaurante(Integer capRestaurante){
        for(Restaurante res : Restaurante.values()){
            if (res.isInRange(capRestaurante)) {
                return res;
            }
        }
        return Restaurante.MAYOR50;
    }
}
