/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package Paquete.TiposAlojamiento.TiposHoteles;
import Paquete.TiposAlojamiento.Hotel;
import Paquete.Enums.Gimnasio;
import Paquete.Enums.Restaurante;
/*• Hotel **** Cantidad de Habitaciones, Número de camas, Cantidad de Pisos, Gimnasio,
Nombre del Restaurante, Capacidad del Restaurante, Precio de las Habitaciones.
 */
public class Hotel4 extends Hotel {

    protected Gimnasio gimnasio;
    protected String nomRestaurante;
    protected Restaurante capRestaurante;

    public Hotel4(Gimnasio gimnasio, String nomRestaurante, Restaurante capRestaurante, Integer habitaciones, Integer numCamas, Integer cantPisos, String nombre, String direccion, String localidad, String gerente) {
        super(habitaciones, numCamas, cantPisos, nombre, direccion, localidad, gerente);
        this.gimnasio = gimnasio;
        this.nomRestaurante = nomRestaurante;
        this.capRestaurante = capRestaurante;
    }
    
    
    public Hotel4(String gimnasio,String nomRestaurante,Integer capRestaurante,
            Integer habitaciones,Integer numCamas,Integer cantPisos,
            String nombre, String direccion, String localidad, String gerente){
        
        super(habitaciones, numCamas, cantPisos, nombre, direccion, localidad, gerente);
        
        this.gimnasio = Gimnasio.conseguirGimnasio(gimnasio);
        this.nomRestaurante = nomRestaurante;
        this.capRestaurante = Restaurante.conseguirRestaurante(capRestaurante);
        
    }
    public Hotel4(){
        
    }
    /*
    PrecioHabitación = $50 + ($1 x capacidad del hotel) + (valor agregado por restaurante) + (valor
agregado por gimnasio) + (valor agregado por limosinas).
    */
    @Override
    public void precio(){
        precioHabitacion+=(double) (1*habitaciones)+capRestaurante.getPrecio()+gimnasio.getPrecio();
    }
    
    
    public void setGimnasio(Gimnasio gimnasio){
        this.gimnasio = gimnasio;
    }
    public void setNomRestaurante(String nomRestaurante){
        this.nomRestaurante = nomRestaurante;
    }
    public void setCapRestaurante(Restaurante capRestaurante){
        this.capRestaurante = capRestaurante;
    }
    
    
    public Gimnasio getGimnasio(){
        return gimnasio;
    }
    public String getNomRestaurante(){
        return nomRestaurante;
    }
    public Restaurante getCapRestaurante(){
        return capRestaurante;
    }

    @Override
    public String toString(){
        return super.toString()+" con gimnasio tipo "+gimnasio.getTipo()
                +" con el restaurante "+nomRestaurante+" con capacidad de "+ capRestaurante;
    }
}
