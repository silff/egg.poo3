/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package Paquete.TiposAlojamiento.TiposHoteles;

import Paquete.Enums.Gimnasio;
import Paquete.Enums.Restaurante;

/*• Hotel ***** Cantidad de Habitaciones, Número de camas, Cantidad de Pisos, Gimnasio,
Nombre del Restaurante, Capacidad del Restaurante, Cantidad Salones de
Conferencia, Cantidad de Suites, Cantidad de Limosinas, Precio de las Habitaciones.
 */
public class Hotel5 extends Hotel4 {

    private Integer cantSalonesConf;
    private Integer cantSuites;
    private Integer cantLimosinas;

    public Hotel5(Integer cantSalonesConf, Integer cantSuites, Integer cantLimosinas, Gimnasio gimnasio, String nomRestaurante, Restaurante capRestaurante, Integer habitaciones, Integer numCamas, Integer cantPisos, String nombre, String direccion, String localidad, String gerente) {
        super(gimnasio, nomRestaurante, capRestaurante, habitaciones, numCamas, cantPisos, nombre, direccion, localidad, gerente);
        this.cantSalonesConf = cantSalonesConf;
        this.cantSuites = cantSuites;
        this.cantLimosinas = cantLimosinas;
    }
    
    public Hotel5(Integer cantSalonesConf,Integer cantSuites,Integer cantLimosinas,String gimnasio,String nomRestaurante,Integer capRestaurante,
            Double precioHab,Integer habitaciones,Integer numCamas,Integer cantPisos,
            String nombre, String direccion, String localidad, String gerente){
        
        super(gimnasio, nomRestaurante, capRestaurante, habitaciones, numCamas, cantPisos,
             nombre,  direccion,  localidad,  gerente);
        
        this.cantSalonesConf = cantSalonesConf;
        this.cantSuites = cantSuites;
        this.cantLimosinas = cantLimosinas;   
    }
    /*
    PrecioHabitación = $50 + ($1 x capacidad del hotel) + (valor agregado por restaurante) + (valor
agregado por gimnasio) + (valor agregado por limosinas).
    */
    @Override
    public void precio(){
        super.precio();
        precioHabitacion+= (double)(cantLimosinas*15);
    }
    
    public void setCantSalonesConf(Integer cantSalonesConf){
        this.cantSalonesConf = cantSalonesConf;
    }
    public void setCantSuites(Integer cantSuites){
        this.cantSuites = cantSuites;
    }
    public void setCantLimosinas(Integer cantLimosinas){
        this.cantLimosinas = cantLimosinas;
    }
    
    public Integer getCantSalonesConf(){
        return cantSalonesConf;
    }
    public Integer getCantSuites(){
        return cantSuites;
    }
    public Integer getCantLimosinas(){
        return cantLimosinas;
    }
    @Override
    public String toString(){
        return super.toString()+" tiene "+ cantSalonesConf+"  salones de conferencia, tiene "+cantSuites+" suites y "+cantLimosinas+" limosinas";
    }
}
