

package Paquete.TiposAlojamiento;
import Paquete.Alojamiento.Alojamiento;
/*En contraste, los Alojamientos Extra hoteleros proveen servicios diferentes a los de los
hoteles, estando más orientados a la vida al aire libre y al turista de bajos recursos. Por cada
Alojamiento Extrahotelero se indica si es privado o no, así como la cantidad de metros
cuadrados que ocupa.
 */
public abstract class ExtraHotelero extends Alojamiento {

    protected Boolean privado;
    protected Double metros2;
    
    public ExtraHotelero(Boolean privado,Double metros2,String nombre, String direccion, String localidad, String gerente){
        super(nombre, direccion, localidad, gerente);
        this.privado = privado;
        this.metros2 = metros2;
    }
    public ExtraHotelero(){
    }
    
    public void setPrivado(Boolean privado) {
        this.privado = privado;
    }
    public Boolean getPrivado() {
        return privado;
    }
    public void setMetros2(Double metros2) {
        this.metros2 = metros2;
    }
    public Double getMetros2() {
        return metros2;
    }
    @Override
    public String toString(){
        String privado1="no es privado";
        if (this.privado) {
            privado1 = "es privado";
        }
        return super.toString()+privado1+" tiene "+metros2+" cuadrados "+"con un precio de "+precioHabitacion;
    }
}
