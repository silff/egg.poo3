/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package Paquete.TiposAlojamiento;
import Paquete.Alojamiento.Alojamiento;
/*Los Hotel tienen como atributos: Cantidad de Habitaciones, Número de Camas, Cantidad de
Pisos, Precio de Habitaciones. Y estos pueden ser de cuatro o cinco estrellas. Las
características de las distintas categorías son las siguientes:
 */
public abstract class Hotel extends Alojamiento {

    protected Integer habitaciones;
    protected Integer numCamas;
    protected Integer cantPisos;
    
    
    public Hotel(Integer habitaciones,Integer numCamas,Integer cantPisos,String nombre, String direccion, String localidad, String gerente){
        super(nombre, direccion, localidad, gerente);
        this.habitaciones = habitaciones;
        this.numCamas = numCamas;
        this.cantPisos = cantPisos;
    }
    public Hotel(){
        
    }
    public void setHabitaciones(Integer habitaciones){
        this.habitaciones = habitaciones;
    }
    public void setNumCamas(Integer numCamas){
        this.numCamas = numCamas;
    }
    public void setCantPisos(Integer cantPisos){
        this.cantPisos = cantPisos;
    }
    
    public Integer getHabitaciones(){
        return habitaciones;
    }
    public Integer getNumCamas(){
        return numCamas;
    }
    public Integer getCantPisos(){
        return cantPisos;
    }
    
    @Override
    public String toString(){
        return super.toString()+" tipo Hotel con "+habitaciones+" con "+numCamas+
                "camas c/u de "+cantPisos+" pisos con un precio de "+precioHabitacion+" ademas incluye ";
    }
    
}
