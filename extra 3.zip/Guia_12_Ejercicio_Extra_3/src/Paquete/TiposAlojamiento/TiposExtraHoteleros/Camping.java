/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package Paquete.TiposAlojamiento.TiposExtraHoteleros;
import Paquete.TiposAlojamiento.ExtraHotelero;
import Paquete.Enums.Restaurante;
import java.util.Scanner;
/*Para los Camping se indica la capacidad máxima de carpas, la cantidad de baños
disponibles y si posee o no un restaurante dentro de las instalaciones.
 */
public class Camping extends ExtraHotelero {

    private Integer maxCarpas;
    private Integer cantBanios;
    private Restaurante restaurante;

    public Camping(Integer maxCarpas, Integer cantBanios, Restaurante restaurante, Boolean privado, Double metros2, String nombre, String direccion, String localidad, String gerente) {
        super(privado, metros2, nombre, direccion, localidad, gerente);
        this.maxCarpas = maxCarpas;
        this.cantBanios = cantBanios;
        this.restaurante = restaurante;
    }
    
    public Camping(Integer maxCarpas,Integer cantBanios,Boolean restaurante,Boolean privado,Double metros2,String nombre, String direccion, String localidad, String gerente){
        super(privado, metros2, nombre, direccion, localidad, gerente);
        this.maxCarpas = maxCarpas;
        this.cantBanios = cantBanios;
        Scanner leer = new Scanner(System.in).useDelimiter("\n");
        Integer capRestaurante = 0;
        
        if (restaurante) {
            System.out.println("De cuantos es la capacidad del restaurante? ");
            capRestaurante = leer.nextInt();//100000
        }
        
        this.restaurante = Restaurante.conseguirRestaurante(capRestaurante);
    }
    
    public Camping(){
        
    }
    public void setMaxCarpas(Integer maxCarpas) {
        this.maxCarpas = maxCarpas;
    }
    public Integer getMaxCarpas() {
        return maxCarpas;
    }
    public void setCantBanios(Integer cantBanios) {
        this.cantBanios = cantBanios;
    }
    public Integer getCantBanios() {
        return cantBanios;
    }
    public Restaurante getRestaurante(){
        return restaurante;
    }
    public void setRestaurante(Restaurante restaurante){
        this.restaurante = restaurante;
    }
    @Override
    public String toString(){
        String restaurante1=" y no tiene restaurante ";
        if (restaurante.getPrecio()!=0) {
            restaurante1=" y tiene un restaurante con un precio de "+restaurante.getPrecio();
        }
        return super.toString()+" tiene una max capacidad de carpas de "+maxCarpas
                +" con "+cantBanios+" banios "+restaurante1;
    }
    /*
    PrecioHabitación = $50 + ($1 x capacidad del hotel) + (valor agregado por restaurante) + (valor
agregado por gimnasio) + (valor agregado por limosinas).
    */
    @Override
    public void precio(){
        precioHabitacion+=restaurante.getPrecio()-50d;
    }
}
