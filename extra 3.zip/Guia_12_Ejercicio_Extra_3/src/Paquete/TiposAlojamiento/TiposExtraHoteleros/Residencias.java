/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package Paquete.TiposAlojamiento.TiposExtraHoteleros;
import Paquete.TiposAlojamiento.ExtraHotelero;
import Paquete.Enums.Gremio;
/* Para las residencias se indica la cantidad de habitaciones, si se hacen o
no descuentos a los gremios y si posee o no campo deportivo.
 */
public class Residencias extends ExtraHotelero {

    private Integer habitaciones;
    private Gremio gremio;
    private Boolean campoDeportivo;

    public Residencias(Integer habitaciones, Gremio gremio, Boolean campoDeportivo, Boolean privado, Double metros2, String nombre, String direccion, String localidad, String gerente) {
        super(privado, metros2, nombre, direccion, localidad, gerente);
        this.habitaciones = habitaciones;
        this.gremio = gremio;
        this.campoDeportivo = campoDeportivo;
    }
    
    public Residencias(Integer habitaciones,String gremio,Boolean campoDeportivo,Boolean privado,Double metros2,String nombre, String direccion, String localidad, String gerente){
        super(privado, metros2, nombre, direccion, localidad, gerente);
        this.habitaciones = habitaciones;
        this.campoDeportivo = campoDeportivo;
        this.gremio=Gremio.conseguirDescuento(gremio);
    }
    public Residencias(){
        
    }
    public void setHabitaciones(Integer habitaciones) {
        this.habitaciones = habitaciones;
    }
    public Integer getHabitaciones() {
        return habitaciones;
    }
    public void setGremio(Gremio gremio) {
        this.gremio = gremio;
    }
    public Gremio getGremio() {
        return gremio;
    }
    public void setCampoDeportivo(Boolean campoDeportivo) {
        this.campoDeportivo = campoDeportivo;
    }
    public Boolean getCampoDeportivo() {
        return campoDeportivo;
    }
    
    @Override
    public void precio(){
        precioHabitacion+=(double) (1*habitaciones);
        precioHabitacion=precioHabitacion-(precioHabitacion*gremio.getDescuento());
    }
    
    @Override
    public String toString(){
        String campoDeportivo1=" y no tiene campo deportivo ";
        if (this.campoDeportivo) {
            campoDeportivo1=" y tiene campo deportivo ";
        }
        String gremio1 = " no tiene descuento con gremios";
        if (this.gremio.getDescuento()!=0) {
            gremio1 = " tiene descuento con "+this.gremio.getGremio()+" de "+ this.gremio.getDescuento()*100+" %";
        }
        return super.toString()+" tiene "+habitaciones
                +" habitaciones"+campoDeportivo1+" y "+gremio;
    }
}
