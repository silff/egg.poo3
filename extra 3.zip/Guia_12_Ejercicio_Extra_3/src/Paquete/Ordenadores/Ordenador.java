/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package Paquete.Ordenadores;
import Paquete.Alojamiento.Alojamiento;
import java.util.Comparator;
import Paquete.TiposAlojamiento.Hotel;
import Paquete.TiposAlojamiento.TiposExtraHoteleros.Camping;
import Paquete.TiposAlojamiento.TiposExtraHoteleros.Residencias;
/*• todos los alojamientos.
• todos los hoteles de más caro a más barato.
• todos los campings con restaurante
• todos las residencias que tienen descuento.
 */
public class Ordenador{

    public static Comparator<Alojamiento> OrdenPrecioCaroBarato = new Comparator<Alojamiento>() {
        @Override
        public int compare(Alojamiento h1, Alojamiento h2) {
            return Double.compare(h1.getPrecioHabitacion(), h2.getPrecioHabitacion());
        }
    };

    public static Comparator<Camping> AdmitirCampingRestaurante = new Comparator<Camping>() {
        @Override
        public int compare(Camping c1, Camping c2) {

            boolean c1CumpleCriterio = c1.getRestaurante().getPrecio() > 0;
            boolean c2CumpleCriterio = c2.getRestaurante().getPrecio() > 0;

            // Realizar la comparación en base al cumplimiento del criterio
            if (c1CumpleCriterio && !c2CumpleCriterio) {
                return -1; // h1 va antes que h2
            } else if (!c1CumpleCriterio && c2CumpleCriterio) {
                return 1; // h1 va después que h2
            } else {
                return 0; // h1 y h2 tienen el mismo cumplimiento del criterio, sin preferencia de orden
            }
        }
    };
    
    public static Comparator<Residencias> AdmitirResidenciasDescuento = new Comparator<Residencias>() {
        @Override
        public int compare(Residencias r1, Residencias r2) {

            boolean r1CumpleCriterio = r1.getGremio().getDescuento() > 0;
            boolean r2CumpleCriterio = r2.getGremio().getDescuento() > 0;

            // Realizar la comparación en base al cumplimiento del criterio
            if (r1CumpleCriterio && !r2CumpleCriterio) {
                return -1; // h1 va antes que h2
            } else if (!r1CumpleCriterio && r2CumpleCriterio) {
                return 1; // h1 va después que h2
            } else {
                return 0; // h1 y h2 tienen el mismo cumplimiento del criterio, sin preferencia de orden
            }
        }
    };
}
