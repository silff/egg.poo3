/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package Paquete.Alojamiento;

/*Una compañía de promociones turísticas desea mantener información sobre la infraestructura
de alojamiento para turistas, de forma tal que los clientes puedan planear sus vacaciones de
acuerdo con sus posibilidades. Los alojamientos se identifican por un nombre, una dirección,
una localidad y un gerente encargado del lugar. La compañía trabaja con dos tipos de
alojamientos: Hoteles y Alojamientos Extrahoteleros.
 */
public abstract class Alojamiento{

    protected String nombre;
    protected String direccion;
    protected String localidad;
    protected String gerente;
    protected Double precioHabitacion = 50d;
    
    public Alojamiento(String nombre, String direccion, String localidad, String gerente){
        this.nombre = nombre;
        this.direccion = direccion;
        this.localidad = localidad;
        this.gerente = gerente;
    }
    public Alojamiento(){
    }
    public void setNombre(String nombre){
        this.nombre = nombre;
    }
    public void setDireccion(String direccion){
        this.direccion = direccion;
    }
    public void setLocalidad(String localidad){
        this.localidad = localidad;
    }
    public void setGerente(String gerente){
        this.gerente = gerente;
    }
    public String getNombre(){
        return nombre;
    }
    public String getDireccion(){
        return direccion;
    }
    public String getLocalidad(){
        return localidad;
    }
    public String getGerente(){
        return gerente;
    }
    public Double getPrecioHabitacion(){
        return precioHabitacion;
    }
    public void setPrecioHabitacion(Double precioHabitacion){
        this.precioHabitacion = precioHabitacion;
    }
    @Override
    public String toString(){
        return "El alojamiento "+nombre+" en "+ direccion+" de "+ localidad+ " con gerente "+gerente;
    }

    /**
     *Para calcular el precio
     */
    public abstract void precio();
}
